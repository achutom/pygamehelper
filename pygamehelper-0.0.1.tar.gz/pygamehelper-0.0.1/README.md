# pygamehelper
Developed by Asher Thomas Abraham

# Uses of pygame helper
```
helps you to show text on the pygame window easily.
helps you to scale images on the pygame window easily
helps you to rotate images in the pygame window easily
```
# how to scale images with pygame helper
```python
#example
YOUR_IMAGE_NAME = scale_image(pygame.image.load("YOUR_IMAGE_PATH"), TYPE_THE_NUMBER_HERE_TO_SCALE)
```
# how to rotate images with pygame helper
```python
#example
blit_rotate_center(win, self.img, (self.x, self.y), self.angle)
```
# how to show text with pygame helper
```python
#example
blit_text_center(WIN, MAIN_FONT, "THE_TEXT")
```
# Credits
```
Developed by Asher Thomas
Special thanks to Tim Ruscica
```
